<?php
namespace Convertio\Exceptions;

use Exception;

/**
 * CURLException exception is thrown when a the Convertio API encounter connection error
 */
class CURLException extends Exception
{
}
